--
-- Database: `library_test`
--
CREATE DATABASE IF NOT EXISTS `library_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `library_test`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `first_name`, `last_name`) VALUES
(181, 'Chuck', 'Palahniuk'),
(182, 'Chuck', 'Palahniuk');

-- --------------------------------------------------------

--
-- Table structure for table `authors_books`
--

CREATE TABLE `authors_books` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authors_books`
--

INSERT INTO `authors_books` (`id`, `author_id`, `book_id`) VALUES
(1, 10, 6),
(2, 11, 7),
(3, 11, 8),
(4, 12, 18),
(5, 13, 19),
(6, 23, 23),
(7, 24, 24),
(8, 24, 25),
(9, 25, 35),
(10, 26, 36),
(11, 36, 42),
(12, 37, 43),
(13, 37, 44),
(14, 38, 54),
(15, 39, 55),
(16, 49, 61),
(17, 50, 62),
(18, 50, 63),
(19, 51, 73),
(20, 52, 74),
(21, 62, 80),
(22, 63, 81),
(23, 63, 82),
(24, 64, 92),
(25, 65, 93),
(26, 75, 99),
(27, 76, 100),
(28, 76, 101),
(29, 77, 111),
(30, 78, 112),
(31, 88, 118),
(32, 89, 119),
(33, 89, 120),
(34, 90, 130),
(35, 91, 131),
(36, 101, 137),
(37, 102, 138),
(38, 102, 139),
(39, 103, 149),
(40, 104, 150),
(41, 114, 156),
(42, 115, 157),
(43, 115, 158),
(44, 116, 168),
(45, 117, 169),
(46, 127, 175),
(47, 128, 176),
(48, 128, 177),
(49, 129, 187),
(50, 130, 188),
(51, 140, 194),
(52, 141, 195),
(53, 141, 196),
(54, 142, 206),
(55, 143, 207),
(56, 153, 213),
(57, 154, 214),
(58, 154, 215),
(59, 155, 225),
(60, 156, 226),
(61, 166, 232),
(62, 167, 233),
(63, 167, 234),
(64, 168, 244),
(65, 169, 245),
(66, 179, 251),
(67, 180, 252),
(68, 180, 253),
(69, 181, 263),
(70, 182, 264);

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`) VALUES
(266, 'Fight Club'),
(267, 'Fight Club'),
(268, 'Fight Club'),
(269, 'Fight Club');

-- --------------------------------------------------------

--
-- Table structure for table `copies`
--

CREATE TABLE `copies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `copies`
--

INSERT INTO `copies` (`id`, `book_id`, `due_date`, `status`) VALUES
(226, 268, '2016-03-01', 1),
(227, 269, '2016-03-01', 1),
(228, 269, '2016-05-01', 0);

-- --------------------------------------------------------

--
-- Table structure for table `copies_patrons`
--

CREATE TABLE `copies_patrons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `patron_id` int(11) DEFAULT NULL,
  `copy_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `copies_patrons`
--

INSERT INTO `copies_patrons` (`id`, `patron_id`, `copy_id`) VALUES
(1, 48, 1),
(2, 49, 2),
(3, 49, 3),
(4, 69, 4),
(5, 70, 5),
(6, 70, 6),
(7, 80, 18),
(8, 81, 19),
(9, 81, 20),
(10, 91, 34),
(11, 92, 35),
(12, 92, 36),
(13, 102, 50),
(14, 103, 51),
(15, 103, 52),
(16, 113, 66),
(17, 114, 67),
(18, 114, 68),
(19, 115, 80),
(20, 126, 82),
(21, 127, 83),
(22, 127, 84),
(23, 128, 96),
(24, 139, 98),
(25, 140, 99),
(26, 140, 100),
(27, 141, 112),
(28, 152, 114),
(29, 153, 115),
(30, 153, 116),
(31, 154, 128),
(32, 165, 130),
(33, 166, 131),
(34, 166, 132),
(35, 167, 144),
(36, 178, 146),
(37, 179, 147),
(38, 179, 148),
(39, 180, 160),
(40, 191, 162),
(41, 192, 163),
(42, 192, 164),
(43, 193, 176),
(44, 204, 178),
(45, 205, 179),
(46, 205, 180),
(47, 206, 192),
(48, 217, 194),
(49, 218, 195),
(50, 218, 196),
(51, 219, 208),
(52, 220, 209),
(53, 230, 210),
(54, 231, 211),
(55, 231, 212),
(56, 232, 224),
(57, 233, 225),
(58, 243, 226),
(59, 244, 227),
(60, 244, 228);

-- --------------------------------------------------------

--
-- Table structure for table `patrons`
--

CREATE TABLE `patrons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `phone_number` bigint(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `authors_books`
--
ALTER TABLE `authors_books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `copies`
--
ALTER TABLE `copies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `copies_patrons`
--
ALTER TABLE `copies_patrons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `patrons`
--
ALTER TABLE `patrons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=183;
--
-- AUTO_INCREMENT for table `authors_books`
--
ALTER TABLE `authors_books`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=270;
--
-- AUTO_INCREMENT for table `copies`
--
ALTER TABLE `copies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=229;
--
-- AUTO_INCREMENT for table `copies_patrons`
--
ALTER TABLE `copies_patrons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `patrons`
--
ALTER TABLE `patrons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=245;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
